package Controllers;


public class gameVariables {
    
    public static int mapSize = 7;
    public static boolean isDebug; 
    public static boolean isSim;
   
    
    
    private gameVariables()
    {
        
    }
    
    

}
