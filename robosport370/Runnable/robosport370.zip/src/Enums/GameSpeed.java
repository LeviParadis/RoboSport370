package Enums;

public enum GameSpeed {
    GAME_SPEED_1X, GAME_SPEED_2X, GAME_SPEED_4X, GAME_SPEED_16X
}
